package com.example.locatelegacy;

import java.io.File;

import net.minecraftforge.common.MinecraftForge;

import com.example.locatelegacy.client.ResourceReloadHook;
import com.example.locatelegacy.command.LocateCommand;
import com.example.locatelegacy.config.BiomeListManager;
import com.example.locatelegacy.config.BiomeWalkTracker;
import com.example.locatelegacy.config.LocateLegacyConfig;
import com.example.locatelegacy.config.StructureConfigManager;
import com.example.locatelegacy.locate.LocateTaskManager;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;

@Mod(
    modid = LocateLegacy.MODID,
    name = LocateLegacy.NAME,
    version = LocateLegacy.VERSION,
    acceptableRemoteVersions = "*")
public class LocateLegacy {

    public static final String MODID = "locatelegacy";
    public static final String NAME = "LocateLegacy";
    public static final String VERSION = "3.0BETA6";

    private static boolean registered = false;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // 你原来的配置加载
        File cfg = new File(event.getModConfigurationDirectory(), "LocateLegacy.cfg");
        LocateLegacyConfig.load(cfg);

        // 结构配置 & biome 列表
        StructureConfigManager.init(event.getModConfigurationDirectory());
        BiomeListManager.init(event.getModConfigurationDirectory());
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        if (!registered) {
            // ServerTick 驱动 LocateTaskManager.tick()
            FMLCommonHandler.instance()
                .bus()
                .register(new ServerTickDriver());
            FMLCommonHandler.instance()
                .bus()
                .register(new TickHandler());
            // 走过的 biome 记录器（写入 LocateLegacyBiomeList.json）
            FMLCommonHandler.instance()
                .bus()
                .register(new BiomeWalkTracker());

            registered = true;
        }
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new ResourceReloadHook());
    }

    @EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new LocateCommand());
    }

    public static class ServerTickDriver {

        @cpw.mods.fml.common.eventhandler.SubscribeEvent
        public void onServerTick(cpw.mods.fml.common.gameevent.TickEvent.ServerTickEvent e) {
            if (e.phase != cpw.mods.fml.common.gameevent.TickEvent.Phase.END) return;

            // ✅ 关键：推进 locate 扫描
            LocateTaskManager.tick();

            // ✅ 延迟刷盘保存 biomeList
            BiomeListManager.tickSave();
        }
    }
}
