package com.example.locatelegacy.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

/**
 * Utility for loading LocateLegacy override JSONs from "biomepack" resourcepacks.
 *
 * A biomepack is a zip placed in .minecraft/resourcepacks/ (or run/client/resourcepacks in dev)
 * and named "*-biomepack.zip".
 *
 * The pack may contain (supported paths):
 * - config/LocateLegacyBiomeList.json
 * - config/LocateLegacyStructures.json
 * - LocateLegacyBiomeList.json
 * - LocateLegacyStructures.json
 *
 * If multiple biomepacks provide the same file, the last one (by filename sort) wins.
 */
public final class ResourcePackOverrides {

    private ResourcePackOverrides() {}

    public static JsonElement tryLoadOverrideJson(File gameDir, String... candidatePathsInZip) {
        try {
            if (gameDir == null) return null;

            File rpDir = new File(gameDir, "resourcepacks");
            if (!rpDir.isDirectory()) return null;

            File[] files = rpDir.listFiles();
            if (files == null || files.length == 0) return null;

            List<File> packs = new ArrayList<File>();
            for (File f : files) {
                if (f == null || !f.isFile()) continue;
                String n = f.getName()
                    .toLowerCase();
                if (n.endsWith("-biomepack.zip")) packs.add(f);
            }
            if (packs.isEmpty()) return null;

            // Stable deterministic order
            Collections.sort(packs, new Comparator<File>() {

                @Override
                public int compare(File a, File b) {
                    return a.getName()
                        .compareToIgnoreCase(b.getName());
                }
            });

            // "last wins"
            for (int i = packs.size() - 1; i >= 0; i--) {
                File pack = packs.get(i);
                ZipFile zf = null;
                try {
                    zf = new ZipFile(pack);

                    ZipEntry hit = null;
                    for (String p : candidatePathsInZip) {
                        if (p == null || p.length() == 0) continue;
                        ZipEntry e = zf.getEntry(p);
                        if (e != null && !e.isDirectory()) {
                            hit = e;
                            break;
                        }
                    }
                    if (hit == null) continue;

                    InputStream in = zf.getInputStream(hit);
                    BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                    try {
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) {
                            sb.append(line)
                                .append('\n');
                        }
                        // Gson 2.2.x 兼容写法：JsonParser.parse(String)
                        return new JsonParser().parse(sb.toString());
                    } finally {
                        try {
                            br.close();
                        } catch (Throwable ignored) {}
                    }

                } finally {
                    try {
                        if (zf != null) zf.close();
                    } catch (Throwable ignored) {}
                }
            }

        } catch (Throwable t) {
            t.printStackTrace();
        }
        return null;
    }
}
