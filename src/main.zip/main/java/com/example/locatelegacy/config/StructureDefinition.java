package com.example.locatelegacy.config;

import java.util.ArrayList;
import java.util.List;

/**
 * config/LocateLegacyStructures.json 的单个结构定义。
 *
 * 字段约定：
 * - biomeName：纯展示用（给人看），不会参与算法
 * - biomeId：用于过滤定位结果（给机器用），可填一个或多个
 */
public class StructureDefinition {

    /** 展示名（例如：Lich Tower） */
    public String name = "";

    /** 结构ID（例如：lich_tower）。locate 命令只接受这个完整ID，不做关键字匹配。 */
    public String id = "";

    /** 所属模组ID（例如：twilightforest），仅展示/分类用 */
    public String mod = "";

    /** 所属维度（例如：7、-1） */
    public int dim = 0;

    /** 负责生成该结构的 MapGen 类名（建议填完整类名） */
    public String mapGen = "";

    /** 群系名字（仅展示用，例如 Ocean） */
    public String biomeName = "";

    /**
     * 群系过滤：
     * - biomeAll=true：允许全部群系（可配合 biomeIdBlacklist 排除）
     * - biomeIdWhitelist 非空：只允许这些群系
     * - biomeIdBlacklist 非空：允许全部（或 whitelist 结果）后再排除
     */
    public boolean biomeAll = false;

    /** 群系白名单（用于过滤，可填多个） */
    public List<Integer> biomeIdWhitelist = new ArrayList<Integer>();

    /** 群系黑名单（用于过滤，可填多个） */
    public List<Integer> biomeIdBlacklist = new ArrayList<Integer>();

    public boolean isValid() {
        return id != null && !id.trim()
            .isEmpty()
            && mapGen != null
            && !mapGen.trim()
                .isEmpty();
    }

    public String fullId() {
        String rawId = (id == null) ? "" : id.trim();
        if (rawId.contains(":")) {
            return rawId.toLowerCase();
        }

        String ns = (mod == null || mod.trim()
            .isEmpty()) ? "minecraft" : mod.trim();
        return (ns + ":" + rawId).toLowerCase();
    }
}
