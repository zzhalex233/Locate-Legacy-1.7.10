package com.example.locatelegacy.client;

import net.minecraftforge.client.event.TextureStitchEvent;

import com.example.locatelegacy.config.BiomeListManager;
import com.example.locatelegacy.config.StructureConfigManager;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;

/**
 * Hook resource pack reload in MC 1.7.10.
 *
 * TextureStitchEvent.Pre is fired every time:
 * - Resource packs are changed
 * - F3 + T is pressed
 *
 * We use it as a reliable "resource reload" signal.
 */
public class ResourceReloadHook {

    @SubscribeEvent
    public void onTextureStitchPre(TextureStitchEvent.Pre event) {

        // 热重载 LocateLegacy 的 JSON 配置
        StructureConfigManager.reload();
        BiomeListManager.reload();

        System.out.println("[LocateLegacy] Resource pack reload detected, configs reloaded.");
    }
}
